# CHARLES-XMD

<!-- Glowing Header -->

<h1 align="center">
  <img src="https://readme-typing-svg.herokuapp.com?font=Fira+Code&size=25&duration=3000&color=00FF00&background=000000&center=true&vCenter=true&width=600&lines=☣️+CHARLES+XMD+BOT;💬+Fast,+Simple+WhatsApp+MD+Bot;💻+Created+with+Zokou+Framework;🇰🇪+By+Charles+XMD✅" alt="Typing Animation">
</h1>

<!-- Banner Image -->
<p align="center">
  <a href="https://files.catbox.moe/96lvnp.jpg">
    <img src="https://files.catbox.moe/96lvnp.jpg" width="100%" height="auto">
  </a>
</p>

[![Typing SVG](https://readme-typing-svg.herokuapp.com?font=Rockstar-ExtraBold&color=green&lines=■+■+■+■+■+PLEASE+FORK+THE+REPO+TO+SUPPORT)](https://git.io/typing-svg)

---

<h4 align="left">💻 Developer</h4>
<p align="left">
<a href='https://github.com/charlesxmd' target="_blank"><img alt='Github' src='https://img.shields.io/badge/-Github%20Follow-blue?style=for-the-badge&logo=github&logoColor=white'/></a>
</p>

---

## 🚀 Deploy the Bot Easily

## ⭐ Fork & Star this Repository  
Support the project by giving a ⭐ and forking the repo.

[![Fork Repo](https://img.shields.io/badge/Github-Fork%20Repo-orange?style=for-the-badge&logo=Github)](https://github.com/charlesxmd/CHARLES-XMD/fork)

---
PAIR CODE 

<p align="left">
  <a href="https://charle-ke.onrender.com">
    <img title="PAIR CODE" src="https://img.shields.io/badge/GET SESSION-neonred?style=for-the-badge&logo=charleske" width="220" height="38.45"/>
  </a>
</p>

## 🛠 Deployment Methods

## 🟪 Railway

[![Deploy on Railway](https://img.shields.io/badge/-DEPLOY-purple?style=for-the-badge&logo=railway&logoColor=white)](https://railway.app/login)

---

## ⚫ Render

[![Deploy on Render](https://img.shields.io/badge/-DEPLOY-black?style=for-the-badge&logo=render&logoColor=white)](https://dashboard.render.com)

---

## 🟣 Heroku

[![Deploy on Heroku](https://img.shields.io/badge/-DEPLOY-purple?style=for-the-badge&logo=heroku&logoColor=white)](https://dashboard.heroku.com/new?template=https://github.com/charlesxmd/CHARLES-XMD)

---

## 📡 Support the Bot by Joining Our WhatsApp Channel

<a href="https://whatsapp.com/channel/0029Vao2hgeChq6HJ5bmlZ3K"><img title="WHATSAPP CHANNEL" src="https://img.shields.io/badge/FOLLOW-WhatsApp%20Channel-brightgreen?style=for-the-badge&logo=whatsapp" width="280" height="38.45"/></a>

---

<!-- Glowing Footer -->
<p align="center">
  <img src="https://i.imgur.com/dBaSKWF.gif" height="40" width="100%">
</p>

<h3 align="center">
  <img src="https://readme-typing-svg.herokuapp.com?font=Fira+Code&size=20&duration=3000&color=FFFFFF&background=000000&center=true&vCenter=true&width=600&lines=💎+CHARLES+XMD+Bot+Edition;⚡+Lightweight+WhatsApp+Bot+by+Charles+🇰🇪" alt="Footer Animation">
</h3>

<p align="center">
  <img src="https://i.imgur.com/dBaSKWF.gif" height="40" width="100%">
</p>
