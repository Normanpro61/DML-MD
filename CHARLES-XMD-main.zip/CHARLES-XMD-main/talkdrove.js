
{
    "bot-name": "CHARLESKE-XMD_BOT",
    "description": "Whiskey Sockets Baileys Whatsapp bot By Mr Charleskenya1",
    "logo": "https://files.catbox.moe/z62ts0.jpg",
    "keywords": ["bot"],
    "documentation-link": "https://charle-ke.onrender.com/",
    "owner-verification": "Charlesodhiamboofficiall@gmail.com",  
    "env": {
      "SESSION_ID": {
        "description": "Put your SESSION_ID here. Make sure it starts with ey~  or get session id from here,  https://charle-ke.onrender.com/",
        "value":"",
        "required": true        
    },
      "PREFIX": {
        "description": "Bot command prefix, (e.g, . , ! @ etc",
        "value":".",
        "required": true        
    },     
    "STICKER_NAME": {
      "description": "type your sticker pack name.",
      "required": false,
      "value": "CHARLESKE-XMD 𝙱𝙾𝚃"  
    },    
    "MODE": {
      "description": "select your bot work type public-private-inbox-group.",
      "required": false,
      "value": "public"      
    },        
    "ALWAYS_ONLINE": {
      "description": "Make it true if want always online.",
      "required": false,
      "value": "false"  
   },      
    "AUTO_VOICE": {
      "description": "Make it true if want automatic voice reply .",
      "required": false,
      "value": "false"
   }, 
    "AUTO_REPLY": {
      "description": "Make it true if you want automatic reply.",
      "required": false,
      "value": "false"
   }, 
    "AUTO_STICKER": {
      "description": "Make it true if you want automatic sticker.",
      "required": false,
      "value": "false"
   }, 
    "AUTO_STATUS_REPLY": {
      "description": "Make it true for auto reply msg on status seen.",
      "required": true,
      "value": "false"
   }, 
    "AUTO_STATUS_MSG": {
      "description": "Type custom message on status reply",
      "required": true,
      "value": "false"   
   },     
    "OWNER_NAME": {
      "description": "Type Bot Owner Name.",
      "required": false,
      "value": "®charleske"
   }, 
    "OWNER_NUMBER": {
      "description": "put the owner number for bot.",
      "required": false,
      "value": "254759626063"
   }, 
    "BOT_NAME": {
      "description": "Type here the bot name.",
      "required": false,
      "value": "CHARLESKE-XMD"
   }, 
    "ANTI_LINK": {
      "description": "Make it true if you want bot auto remove group link.",
      "required": true,
      "value": "true"      
   },    
    "ANTI_BAD": {
      "description": "Make it true if you want bot auto delete bad words.",
      "required": false,
      "value": "false"
    }, 
      "DELETE_LINKS": {
      "description": "remove links from group automatically without removing member",
      "required": false,
      "value": "false"
    },    
    "AUTO_RECORDING": {
      "description": "Make it true if you want auto recoding.",
      "required": false,
      "value": "false"
    },
    "AUTO_TYPING": {
      "description": "Make it true if you want auto typing.",
      "required": false,
      "value": "false"
    },
    "AUTO_REACT": {
      "description": "Make it true if you want react on every message.",
      "required": false,
      "value": "false"
    },    
    "CUSTOM_REACT": {
      "description": "Make it true if you want custom reactions.",
      "required": false,
      "value": "false"      
    },    
    "CUSTOM_REACT_EMOJIS": {
      "description": "put here custom react react emojis.",
      "required": false,
      "value": "💝,💖,💗,❤️‍🩹,❤️,🧡,💛,💚,💙,💜,🤎,🖤,🤍"    
    }, 
    "READ_MESSAGE": {
      "description": "Make it true if you want bot read your all sms just now.",
      "required": false,
      "value": "false"
    }
  }
}
